$(document).ready(function() {

    $(".hamburger").on("click", function () {
        $(this).toggleClass("active");
        $(".nav-links").toggleClass("active");
    });

    // ========== img-slider =============

    let slideIndex = 1;

    showSlides(slideIndex);

    $(".next").click(function() {
        showSlides(slideIndex += 1);
    });

    $(".prev").click(function() {
        showSlides(slideIndex -= 1);
    });

    setInterval(function() {
        showSlides(slideIndex += 1);
    },5000);

    function showSlides(n) {
        let slides = $(".mySlides");

        if (n > slides.length) {
            slideIndex = 1; 
        }
        if (n < 1) {  
            slideIndex = slides.length; 
        }

        slides.each(function() {
            $(this).css("display", "none");
        });

        slides.eq(slideIndex - 1).css("display", "block");
    }

    // ================== img-slider-end =================


    // ================== paragaraph-slider ===============

    let paraslideIndex = 1;

    $(".prev-para").on("click", function() {
        showpslides(paraslideIndex -= 1);
    });

    $(".next-para").on("click", function() {
        showpslides(paraslideIndex += 1);
    });

    $(".pdot").on("click", function() {
        let n = $(this).index() + 1;
        showpslides(paraslideIndex = n);
    });

    function showpslides(n) {
        let $pslides = $(".mypslides");
        let $pdots = $(".pdot");

        if (n > $pslides.length) { 
            paraslideIndex = 1; 
        }
        if (n < 1) { 
            paraslideIndex = $pslides.length; 
        }

        $pslides.hide();

        $pdots.removeClass("pactive");

        $pslides.eq(paraslideIndex - 1).show();
        $pdots.eq(paraslideIndex - 1).addClass("pactive");
        }

    showpslides(paraslideIndex);


    // ================== paragaraph-slider ===============

    // ================== input-page ===============

    $(".blog-sub-btn").click(function () {

        let email = $("input[name='email']").val().trim();

        if (validateEmail(email)) {
            alert("Thank you for subscribing with email: " + email);
            $("input[name='email']").val("");
        } else {
            alert("Please enter a valid email address.");
        }

        function validateEmail(email) {
            let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
    });

   // ================== input-page-end ===============

});